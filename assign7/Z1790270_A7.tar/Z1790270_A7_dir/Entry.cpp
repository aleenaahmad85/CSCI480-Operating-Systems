/********************************************************************
CSCI 480 - Assignment 7 - Semester (Fall) 2019

Progammer: Andrew Scheel
Section:   2
TA:        Jingwan Li
Date Due:  12/2/19

Purpose:   This is the what holds the class Entry to be used in assign7.cpp

*********************************************************************/

#include <vector>

using namespace std;

class Entry
{
	public:
		int size;
		string name;
		vector<int> blocks;
};
